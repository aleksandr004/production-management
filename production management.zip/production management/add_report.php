<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "factory";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start(); // Начало сессии для работы с авторизацией
// Получение данных из формы
$report_text = $_POST['report_text'];
$report_date = $_POST['report_date'];

// Проверка авторизации пользователя
if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
    $userLogin = $_SESSION['login'];
    $userPassword = $_SESSION['password'];

    $sqlUserData = "SELECT id_user FROM user_data WHERE login = '$userLogin' AND pass = '$userPassword'";
    $resultUserData = $conn->query($sqlUserData);
    if ($resultUserData->num_rows > 0) {
        $row = $resultUserData->fetch_assoc();
        $userId = $row['id_user'];



// Добавление данных в таблицу "report_user"
$sql = "INSERT INTO report_user (report_text, report_data, id_user_rep) VALUES ('$report_text', '$report_date', ' $userId')";

if ($conn->query($sql) === TRUE) {
    echo "Успешно добавлено";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
    }
}

$conn->close();
?>