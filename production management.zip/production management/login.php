<?php
session_start();
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "factory"; 

$conn = new mysqli($host, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}


$login = $_POST['login'];
$password = $_POST['password'];
$_SESSION['login']=$login;
$_SESSION['password']=$password;



$login = mysqli_real_escape_string($conn, $login);
$password = mysqli_real_escape_string($conn, $password);


$sql = "SELECT * FROM user_data WHERE login = '$login' AND pass = '$password'";
$result = $conn->query($sql);
$_SESSION['id_user']=$id_user;

if ($result->num_rows > 0) {
   
    $user = $result->fetch_assoc();

 
    switch ($user['access']) {
        case 'рабочий':
            $_SESSION['user'] = $user;
            header("Location: rab.php");
            break;
        case 'кладовщик':
            $_SESSION['user'] = $user;
            header("Location: klad.php");
            break;
        case 'менеджер':
            $_SESSION['user'] = $user;
            header("Location: manager.php");
            break;
        default:
            echo "Недопустимый уровень доступа";
            break;
    }
} else {
    echo "Неверный логин или пароль";
}

$conn->close();
?>