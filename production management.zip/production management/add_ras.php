<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "factory";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start(); 

$data_start = $_POST['data_start'];
$data_end = $_POST['data_end'];
$day_data = $_POST['day_data'];
$week_data = $_POST['week_data'];
$month_data = $_POST['month_data'];



if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
    $userLogin = $_SESSION['login'];
    $userPassword = $_SESSION['password'];

    $sqlUserData = "SELECT id_user FROM user_data WHERE login = '$userLogin' AND pass = '$userPassword'";
    $resultUserData = $conn->query($sqlUserData);


if ($resultUserData->num_rows > 0) {
    $row = $resultUserData->fetch_assoc();
    $userId = $row['id_user'];


$sql = "INSERT INTO shedule (data_start, data_end, day_data, week_data, month_data, user_id_sh) VALUES ('$data_start', '$data_end', '$day_data', '$week_data', '$month_data', '$userId')";

if ($conn->query($sql) === TRUE) {
    echo "Успешно добавлено";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
}

$conn->close();
?>