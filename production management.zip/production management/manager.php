<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Информация о сотруднике</title>
    <link rel="stylesheet" href="style_rab.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Информация о сотруднике</h1>
    </header>
    </nav>
    <form method="get" style="text-align: center;font-size: 30px;">
    <?php
session_start();

if(isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

    // Вывод информации о пользователе
    echo "<strong>Имя:</strong> " . $user['first_name'] . "<br>"."<br>";
    echo "<strong>Фамилия:</strong> " . $user['last_name'] . "<br>"."<br>";
    echo "<strong>Дата рождения:</strong> " . $user['birthday'] . "<br>"."<br>";
    echo "<strong>Должность:</strong> " . $user['access'] . "<br>"."<br>";
    echo "<strong>Телефон:</strong> " . $user['phone'] . "<br>"."<br>";
    echo "<strong>Почта:</strong> " . $user['mail'] . "<br>"."<br>";
} else {
    echo "Пользователь не авторизован";
}
?>
    </form>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
</body>
</html>