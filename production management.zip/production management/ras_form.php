<!DOCTYPE html>
<html>
<head>
    <title>Редактор расписание</title>
    <link rel="stylesheet" href="style_rab.css">
</head>
<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Редактор расписание</h1>
    </header>
    </nav>
    <form action="add_ras.php" method="post">
        <label for="data_start">Начало:</label><br>
        <input type="time" id="data_start" name="data_start"><br>
        <label for="data_end">Конец:</label><br>
        <input type="time" id="data_end" name="data_end"><br>
        <label for="day_data">День:</label><br>
        <input type="text" id="day_data" name="day_data"><br>
        <label for="week_data">День недели:</label><br>
        <input type="text" id="week_data" name="week_data"><br>
        <label for="month_data">Месяц:</label><br>
        <input type="text" id="month_data" name="month_data"><br><br>
        <input type="submit" value="Добавить">
    </form>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
</body>
</html>