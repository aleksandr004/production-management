<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "factory";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$first_name= $_POST['first_name'];
$last_name= $_POST['last_name'];
$birthday= $_POST['birthday'];
$access=$_POST['access'];
$phone=$_POST['phone'];
$mail=$_POST['mail'];
$card=$_POST['card'];
$login=$_POST['login'];
$pass=$_POST['pass'];
$table_us=$_POST['table_us'];
$salary=$_POST['salary'];
$sql = "INSERT INTO user_data (first_name, last_name, birthday, access, phone, mail, card,login, pass, table_us, salary) 
        VALUES ('$first_name', '$last_name', '$birthday','$access','$phone','$mail','$card','$login','$pass','$table_us','$salary')";

if ($conn->query($sql) === TRUE) {
    echo "Регистрация успешна!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>