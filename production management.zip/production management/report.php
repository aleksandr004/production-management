<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Отчёты</title>
    <link rel="stylesheet" href="style_rab.css">
</head>

<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Редактор отчётов</h1>
    </header>
    </nav>
<form action="add_report.php" method="post">
        <label for="report_text">Отчёт:</label><br>
        <textarea id="report_text" name="report_text" rows="4" cols="50"></textarea><br>
        <label for="report_date">Дата:</label><br>
        <input type="date" id="report_date" name="report_date"><br><br>
        <input type="submit" value="Добавить">
    </form>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
    
</body>
</html>
  