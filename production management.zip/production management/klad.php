<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Информация о сотруднике</title>
    <link rel="stylesheet" href="style_rab.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Информация о сотруднике</h1>
    </header>
    </nav>
    <form method="gest" style="text-align: center;font-size: 30px;">
    <?php
session_start();

if(isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

    // Вывод информации о пользователе
    echo "<strong>Имя:</strong> " . $user['first_name'] . "<br>"."<br>";
    echo "<strong>Фамилия:</strong> " . $user['last_name'] . "<br>"."<br>";
    echo "<strong>Дата рождения:</strong> " . $user['birthday'] . "<br>"."<br>";
    echo "<strong>Должность:</strong> " . $user['access'] . "<br>"."<br>";
    echo "<strong>Телефон:</strong> " . $user['phone'] . "<br>"."<br>";
    echo "<strong>Почта:</strong> " . $user['mail'] . "<br>"."<br>";
} else {
    echo "Пользователь не авторизован";
}
?>
    </form>
 <div  class="sidenav">
        <a href="klad.php">Информация о сотруднике</a>
        <a href="rap_klad.php">Расписание</a>
        <a href="resurs_form.php">Заказы</a>
        <a href="inver_product.php">Инвентаризация продукции</a>
        <a href="inver_res.php">Инвентаризация ресурсов</a>
        
      </div>
</body>
</html>