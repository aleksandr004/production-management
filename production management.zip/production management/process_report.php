<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Обработка данных от формы
    $reportTitle = $_POST["reportTitle"];
    $reportContent = $_POST["reportContent"];

    // Здесь вы можете выполнить дополнительные действия, такие как сохранение отчёта в базе данных

    // Пример вывода данных
    echo "<p>Отчёт успешно создан:</p>";
    echo "<p><strong>Заголовок:</strong> $reportTitle</p>";
    echo "<p><strong>Содержание:</strong> $reportContent</p>";
}
?>