<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "factory";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}


session_start(); 


$productName = $_POST['product_name'];
$productQuantity = $_POST['product_quantity'];


if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
    $userLogin = $_SESSION['login'];
    $userPassword = $_SESSION['password'];

$sqlUserData = "SELECT id_user, table_us FROM user_data WHERE login = '$userLogin' AND pass = '$userPassword'";
$resultUserData = $conn->query($sqlUserData);

if ($resultUserData->num_rows > 0) {
    $row = $resultUserData->fetch_assoc();
    $userId = $row['id_user'];
    $userTable = $row['table_us'];

    
    $sqlInsert = "INSERT INTO product_buy (buy_product, buy_q, id_user_buy, buy_table_us) 
                  VALUES ('$productName', $productQuantity, $userId, '$userTable')";

    if ($conn->query($sqlInsert) === TRUE) {
        echo "Продукт успешно заказан!";
    } else {
        echo "Ошибка: " . $sqlInsert . "<br>" . $conn->error;
    }
} else {
    echo "Пользователь не найден.";
}
} else {
echo "Пользователь не авторизован.";
}

$conn->close();
?>