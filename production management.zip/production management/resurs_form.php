<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Ресурсы</title>
    <link rel="stylesheet" href="style_rab.css">
    <script>
    function clearTable() {
            if (confirm("Вы уверены, что хотите очистить таблицу product_buy?")) {
                // Создание AJAX-запроса для выполнения очистки таблицы product_buy
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        location.reload(); // Перезагрузка страницы после очистки таблицы
                    }
                };
                xhr.open("GET", "clear_table.php", true);
                xhr.send();
            }
        }
    </script>
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Заказы</h1>
    </header>
    </nav>
    <div  class="sidenav">
        <a href="klad.php">Информация о сотруднике</a>
        <a href="rap_klad.php">Расписание</a>
        <a href="resurs_form.php">Заказы</a>
        <a href="inver_product.php">Инвентаризация продукции</a>
        <a href="inver_res.php">Инвентаризация ресурсов</a>
    
      </div>
      <form method="post" style="text-align: center;font-size: 30px;">
      <table border="1" style="margin-left: 400px;">
      <tr>
        <th>Название</th>
        <th>Количество</th>
        <th>Стол</th>
      </tr>
     
      <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "factory";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из таблицы "product_buy"
$sql = "SELECT buy_product, buy_q, buy_table_us FROM product_buy";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["buy_product"] . "</td><td>" . $row["buy_q"] . "</td><td>" . $row["buy_table_us"] . "</td></tr>";
    }
} else {
    
}
$conn->close();
?>
      </table>
      <br>
    
      </form>
      
    </body>
    </html>