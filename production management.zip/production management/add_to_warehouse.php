<?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'factory';

    // Соединение с базой данных
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die('Connection failed: ' . mysqli_connect_error());
    }

    session_start();
    $resurs = $_POST['resurs'];
    $quantity = $_POST['quantity'];
    $stand = $_POST['stand'];

    // Проверка авторизации пользователя
    if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
        $userLogin = $_SESSION['login'];
        $userPassword = $_SESSION['password'];
    // Получение id_user и table_us пользователя
    $sqlUserData = "SELECT id_user FROM user_data WHERE login = '$userLogin' AND pass = '$userPassword'";
    $resultUserData = $conn->query($sqlUserData);

    if ($resultUserData->num_rows > 0) {
        $row = $resultUserData->fetch_assoc();
        $userId = $row['id_user'];
// Вставка данных в таблицу warehouse
            $query = "INSERT INTO warehouse (resurs, quantity, stand, id_user_res) VALUES ('$resurs', '$quantity', '$stand', '$userId')";
            if (mysqli_query($conn, $query)) {
                echo 'Ресурс успешно добавлен!';
            } else {
                echo 'Failed to add data to warehouse: ' . mysqli_error($conn);
            }
        }
    } else {
        echo 'Invalid login or password.';
    }


    mysqli_close($conn);
    ?>