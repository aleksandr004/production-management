<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="style_rab.css">
</head>
<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Регистрация пользователей</h1>
    </header>
    </nav>
    <div class="container">
        <form action="register_app.php" method="POST">
            <label for="first_name">Имя:</label>
            <input type="text" id="first_name" name="first_name" required> <br>
            
            <label for="last_name">Фамилия:</label>
            <input type="text" id="last_name" name="last_name" required> <br>
            
            <label for="birthday">Дата рождения:</label>
            <input type="date" id="birthday" name="birthday" required> <br>

            <label for="access">Должность:</label>
            <input type="text" id="access" name="access" required> <br>
            <label for="phone">Номер телефона:</label>
            <input type="text" id="phone" name="phone" required> <br>
            <label for="mail">Почта:</label>
            <input type="text" id="mail" name="mail" required> <br>
            <label for="card">Карта:</label>
            <input type="text" id="card" name="card" required> <br>
            <label for="login">Логин:</label>
            <input type="text" id="login" name="login" required> <br>
            <label for="pass">Пароль:</label>
            <input type="password" id="pass" name="pass" required> <br>
            <label for="table_us">Рабочий стол:</label>
            <input type="text" id="table_us" name="table_us" required> <br>
            <label for="salary">Зарплата:</label>
            <input type="money" id="salary" name="salary" required> <br>
            
            
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
</body>
</html>