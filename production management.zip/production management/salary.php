<!DOCTYPE html>
<html>
<head>
    <title>Получение данных пользователя</title>
    <link rel="stylesheet" href="style_rab.css">
</head>
<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Выплата зарплаты</h1>
    </header>
    </nav>
    <form method="post" action="">
        <label for="firstName">Имя:</label>
        <input type="text" id="firstName" name="firstName">
        <label for="lastName">Фамилия:</label>
        <input type="text" id="lastName" name="lastName">
        <button type="submit" name="submit">Получить данные</button>
    </form>
<div style="text-align: center;">
    <?php
    if(isset($_POST['submit'])) {
        // Подключение к базе данных (замените на свои данные)
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "factory";

        // Создание подключения
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Проверка подключения
        if ($conn->connect_error) {
            die("Ошибка подключения: " . $conn->connect_error);
        }

        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];

        // SQL запрос для получения данных пользователя
        $sql = "SELECT * FROM user_data WHERE first_name='$firstName' AND last_name='$lastName'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Вывод информации о пользователе
            while($row = $result->fetch_assoc()) {
                echo"<p>Имя: " . $row['first_name'] . "</p>";
                echo "<p>Фамилия: " . $row['last_name'] . "</p>";
                echo "<p>Дата рождения: " . $row['birthday'] . "</p>";
                echo "<p>Доступ: " . $row['access'] . "</p>";
                echo "<p>Телефон: " . $row['phone'] . "</p>";
                echo "<p>Почта: " . $row['mail'] . "</p>";
                echo "<p>Карта: " . $row['card'] . "</p>";
                echo "<p>Пропуски: " . $row['absenteeism'] . "</p>";
                echo "<form method='post' action='update_salary.php'>";
                echo "<p>Зарплата: <input type='text' name='newSalary' value='" . $row['salary'] . "'>";
                echo "<input type='hidden' name='firstName' value='$firstName'>";
                echo "<input type='hidden' name='lastName' value='$lastName'>";
                echo "<button type='submit' name='update'>Подтвердить</button></p>";
                echo "</form>";
            }
        } else {
            echo "Пользователь не найден";
        }

        $conn->close();
    }
    ?>
   </div>

   
     <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
</body>
</html>
