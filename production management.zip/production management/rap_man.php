<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Расписание</title>
    <link rel="stylesheet" href="style_ras.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Расписание</h1>
    </header>
    </nav>
    <form    method="post" style="text-align: center;font-size: 30px;">
    <table border="1" style="margin-left: 400px;">
      <tr>
        <th>Время:</th>
        <th>Дата:</th>
        <th>День недели:</th>
      </tr>
    <?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "factory";
    
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT data_start, data_end, month_data, week_data, day_data FROM shedule";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Вывод данных каждой строки
    while($row = $result->fetch_assoc()) {

        echo "<tr><td>". $row["data_start"]; 
        echo" - " . $row["data_end"]."</td>";
        echo" <td> " . $row["day_data"]; 
        echo"    " . $row["month_data"]."</td>"; 
        echo"<td>" . $row["week_data"]."</td></tr>"; 
    }
} else {
    echo "0 results";
}
if(isset($_POST['absenteeism_button'])) {
     $sqlUpdate = "UPDATE user_data SET absenteeism = absenteeism + 1 WHERE date_field BETWEEN data_start AND data_end";
    $conn->query($sqlUpdate);
}

$conn->close();

    ?>
    </table>
<input type="submit" name="absenteeism_button" value="Отметиться">
</form>


    
    <main id="employeeInfo" style="text-align: center; color: #1350AB;">
    </main>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
      <div id="schedule-container">

      </div>