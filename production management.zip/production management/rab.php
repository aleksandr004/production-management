<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Информация о сотруднике</title>
    <link rel="stylesheet" href="style_rab.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Информация о сотруднике</h1>
    </header>
    </nav>
    <form method="get" style="text-align: center;font-size: 30px;">
    <?php
session_start();

if(isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

    // Вывод информации о пользователе
    echo "Имя: " . $user['first_name'] . "<br>"."<br>";
    echo "Фамилия: " . $user['last_name'] .  "<br>"."<br>";
    echo "Дата рождения: " . $user['birthday'] .  "<br>"."<br>";
    echo "Уровень доступа: " . $user['access'] . "<br>"."<br>";
    echo "Телефон: " . $user['phone'] .  "<br>"."<br>";
    echo "Почта: " . $user['mail'] .  "<br>"."<br>";
} else {
    echo "Пользователь не авторизован";
}
?>
    </form>
 <div  class="sidenav">
        <a href="rab.php">Информация о сотруднике</a>
        <a href="rap_rab.php">Расписание</a>
        <a href="plan.php">План</a>
        <a href="resurs.php">Ресурсы</a>
        <a href="tex_bes.php">Техника безопасности</a>
      </div>
</body>
</html>

