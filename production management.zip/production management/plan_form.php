<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма плана</title>
    <link rel="stylesheet" href="style_rab.css">
</head>
<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Редактор плана</h1>
    </header>
    </nav>
            <form action="add_plan.php" method="post">
        <label for="product_plan">Продукция</label><br>
        <input type="text" id="product_plan" name="product_plan"><br>
        <label for="q_plan">Колличество:</label><br>
        <input type="text" id="q_plan" name="q_plan"><br>
        <label for="plan_time">Время:</label><br>
        <input type="date" id="plan_time" name="plan_time"><br><br>
        <input type="submit" value="Добавить">
    </form>
    <div  class="sidenav">
        <a href="manager.php">Информация о сотруднике</a>
        <a href="rap_man.php">Расписание</a>
        <a href="ras_form.php">Редактор расписание</a>
        <a href="plan_form.php">Редактор плана</a>
        <a href="report.php">Редактор отчётов</a>
        <a href="salary.php">Выплата зарплаты</a>
        <a href="registr.php">Регистрация пользоватлей</a>
        
      </div>
</body>
</html>
    
          
</body>
</html>