<!DOCTYPE html>
<html>
<head>
    <title>Инвентаризация ресурсов</title>
    <link rel="stylesheet" href="style_rab.css">
</head>
<body>
<nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Ивентаризация ресурсов</h1>
    </header>
    </nav>
    <div  class="sidenav">
        <a href="klad.php">Информация о сотруднике</a>
        <a href="rap_klad.php">Расписание</a>
        <a href="resurs_form.php">Заказы</a>
        <a href="inver_product.php">Инвентаризация продукции</a>
        <a href="inver_res.php">Инвентаризация ресурсов</a>
        
      </div>
    <form action="add_to_warehouse.php" method="post">
        <label for="resurs">Ресурсы:</label><br>
        <input type="text" id="resurs" name="resurs"><br>
        <label for="quantity">Колличество:</label><br>
        <input type="text" id="quantity" name="quantity"><br>
        <label for="stand">Стенд:</label><br>
        <input type="text" id="stand" name="stand"><br><br>
        <input type="submit" value="Добавить на склад">
    </form>
</body>
</html>