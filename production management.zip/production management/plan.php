<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>План</title>
    <link rel="stylesheet" href="style_plan.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">План</h1>
    </header>
    </nav>
    <form method="post" style="text-align: center;font-size: 30px;">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "factory";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT product_plan, q_plan, plan_time FROM plan_user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Вывод данных каждой строки
    while($row = $result->fetch_assoc()) {
        echo "Нужно выпустить:       ". $row["product_plan"]."<br>";
        echo "   В колличестве:     ". $row["q_plan"]."    штук";
        echo"     до:   ". $row["plan_time"]. "<br>";
    }
} else {
    echo "0 results";
}
if(isset($_POST['complete_button'])) {  $sqlUpdate = "UPDATE user_data SET plan_completed = CASE 
    WHEN plan_completed = 1 THEN 0 
    ELSE 1 
  END";
$conn->query($sqlUpdate);
}

$conn->close();
        ?>
         <input type="submit" name="complete_button" value="Выполнить / Отменить">
    </form>
    <div  class="sidenav">
        <a href="rab.php">Информация о сотруднике</a>
        <a href="rap_rab.php">Расписание</a>
        <a href="plan.php">План</a>
        <a href="resurs.php">Ресурсы</a>
        <a href="tex_bes.php">Техника безопасности</a>
      </div>
    
        
        
           

        
    
    
   
</body>

</html>