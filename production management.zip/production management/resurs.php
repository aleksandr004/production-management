<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Ресурсы</title>
    <link rel="stylesheet" href="style_res.css">
</head>

<body>
    <nav class="navbar">
    <header>
        <h1 class="zag" style="text-align: center; color: #1350AB;">Ресурсы</h1>
    </header>
    </nav>
    <div  class="sidenav">
        <a href="rab.php">Информация о сотруднике</a>
        <a href="rap_rab.php">Расписание</a>
        <a href="plan.php">План</a>
        <a href="resurs.php">Ресурсы</a>
        <a href="tex_bes.php">Техника безопасности</a>
      </div>
      <form action="process_buy_product.php" method="post" style="text-align: center;font-size: 30px;">
      <label for="product_name">Название продукта:</label>
        <input type="text" id="product_name" name="product_name" required><br><br>
        
        <label for="product_quantity">Количество продукта:</label>
        <input type="number" id="product_quantity" name="product_quantity" required><br><br>
        
        <input type="submit" value="Заказать">
      </form>
     
    

     
    
   
</body>

</html>