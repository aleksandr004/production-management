<?php

// Подключение к базе данных (замените на свои данные)
$servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "factory";


// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if(isset($_POST['update'])) {
    $newSalary = $_POST['newSalary'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];

    // SQL запрос для обновления зарплаты пользователя
    $sql = "UPDATE user_data SET salary='$newSalary' WHERE first_name='$firstName' AND last_name='$lastName'";

    if ($conn->query($sql) === TRUE) {
        echo "Зарплата успешно обновлена!";
    } else {
        echo "Ошибка при обновлении зарплаты: " . $conn->error;
    }
}
$conn->close();
?>